package com.example.calc;

import java.text.BreakIterator;

import android.hardware.Camera.Size;
import android.media.ExifInterface;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class First extends ActionBarActivity {
	int choice;

	double ans;
	Double v1 = (double) 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_first);
		final EditText edtans = (EditText) findViewById(R.id.editText1);
		final EditText edt = (EditText) findViewById(R.id.editText2);
		Button zero = (Button) findViewById(R.id.zero);
		Button one = (Button) findViewById(R.id.one);
		Button two = (Button) findViewById(R.id.two);
		Button three = (Button) findViewById(R.id.three);
		Button four = (Button) findViewById(R.id.four);
		Button five = (Button) findViewById(R.id.five);
		Button six = (Button) findViewById(R.id.six);
		Button seven = (Button) findViewById(R.id.seven);
		Button eight = (Button) findViewById(R.id.eight);
		Button nine = (Button) findViewById(R.id.nine);
		Button backspace = (Button) findViewById(R.id.back_space);
		Button clear = (Button) findViewById(R.id.clear);
		Button plus = (Button) findViewById(R.id.plus);
		Button substract = (Button) findViewById(R.id.substract);
		Button multiply = (Button) findViewById(R.id.multiply);
		Button divide = (Button) findViewById(R.id.divide);
		Button answer = (Button) findViewById(R.id.answer);
		Button reset = (Button) findViewById(R.id.reset);
		Button equal = (Button) findViewById(R.id.equal);
		Button sqrt = (Button) findViewById(R.id.sqroot);
		Button cubert = (Button) findViewById(R.id.cuberoot);
		Button square = (Button) findViewById(R.id.square);
		Button cube = (Button) findViewById(R.id.cube);
		Button power = (Button) findViewById(R.id.any_power);
		Button ln = (Button) findViewById(R.id.log);
		Button log = (Button) findViewById(R.id.log10);
		Button exp = (Button) findViewById(R.id.exp);
		Button sin = (Button) findViewById(R.id.sin);
		Button cos = (Button) findViewById(R.id.cos);
		Button tan = (Button) findViewById(R.id.tan);
		Button sinh = (Button) findViewById(R.id.sinh);
		Button cosh = (Button) findViewById(R.id.cosh);
		Button todeg = (Button) findViewById(R.id.todegree);
		Button torad = (Button) findViewById(R.id.toradian);
		Button dot = (Button) findViewById(R.id.dot);
		Button pi = (Button) findViewById(R.id.pi);

		final StringBuffer storer = new StringBuffer();
		final StringBuffer saver = new StringBuffer();
		pi.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				storer.delete(0, storer.length());
				edt.setText(storer.append("3.141592654"));

			}
		});
		dot.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				edt.setText(storer.append("."));

			}
		});
		torad.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				choice = 15;

				if (storer.length() == 0)
					saver.append("0");
				else
					saver.append(storer);
				storer.delete(0, storer.length());
				edtans.setText(storer);

			}
		});
		todeg.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				choice = 14;

				if (storer.length() == 0)
					saver.append("0");
				else
					saver.append(storer);
				storer.delete(0, storer.length());
				edtans.setText(storer);

			}
		});
		cosh.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				choice = 13;

				if (storer.length() == 0)
					saver.append("0");
				else
					saver.append(storer);
				storer.delete(0, storer.length());
				edtans.setText(storer);

			}
		});
		sinh.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				choice = 12;

				if (storer.length() == 0)
					saver.append("0");
				else
					saver.append(storer);
				storer.delete(0, storer.length());
				edtans.setText(storer);

			}
		});
		tan.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				choice = 11;

				if (storer.length() == 0)
					saver.append("0");
				else
					saver.append(storer);
				storer.delete(0, storer.length());
				edtans.setText(storer);

			}
		});
		ln.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				choice = 6;

				if (storer.length() == 0)
					saver.append("0");
				else
					saver.append(storer);
				storer.delete(0, storer.length());
				edtans.setText(storer);

			}
		});
		log.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				choice = 7;
				if (storer.length() == 0)
					saver.append("0");
				else
					saver.append(storer);
				storer.delete(0, storer.length());
				edtans.setText(storer);

			}
		});
		exp.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				choice = 8;
				if (storer.length() == 0)
					saver.append("0");
				else
					saver.append(storer);
				storer.delete(0, storer.length());
				edtans.setText(storer);

			}
		});
		sin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				choice = 9;
				if (storer.length() == 0)
					saver.append("0");
				else
					saver.append(storer);
				storer.delete(0, storer.length());
				edtans.setText(storer);

			}
		});
		cos.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				choice = 10;
				if (storer.length() == 0)
					saver.append("0");
				else
					saver.append(storer);
				storer.delete(0, storer.length());
				edtans.setText(storer);

			}
		});
		sqrt.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (storer.length() == 0) {
					saver.append("0");

					storer.append("0");

				} else
					saver.append(storer);

				String s = new String(storer);
				Double d = Math.sqrt(Double.parseDouble(s));
				storer.delete(0, storer.length());
				storer.append(d.toString());
				ans = Double.valueOf(new String(storer));
				edtans.setText(storer);
			}
		});
		cubert.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (storer.length() == 0) {
					storer.append("0");
					saver.append("0");
				} else
					saver.append(storer);
				String s = new String(storer);
				Double d = Math.cbrt(Double.parseDouble(s));
				storer.delete(0, storer.length());
				storer.append(d.toString());
				ans = Double.valueOf(new String(storer));

				edtans.setText(storer);
			}
		});
		square.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (storer.length() == 0) {
					storer.append("0");
					// saver.append("0");
				}
				String s = new String(storer);
				Double d = Math.pow(Double.parseDouble(s), 2);
				storer.delete(0, storer.length());
				storer.append(d.toString());
				ans = Double.valueOf(new String(storer));

				edtans.setText(storer);
			}
		});
		cube.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (storer.length() == 0) {
					storer.append("0");
					// saver.append("0");
				}
				String s = new String(storer);
				Double d = Math.pow(Double.parseDouble(s), 3);
				storer.delete(0, storer.length());
				storer.append(d.toString());
				ans = Double.valueOf(new String(storer));

				edtans.setText(storer);
			}
		});
		power.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				choice = 5;
				if (storer.length() == 0) {
					storer.append("0");
					saver.append("0");
				} else
					saver.append(storer);
				storer.delete(0, storer.length());

				edtans.setText(storer);

			}
		});
		reset.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				v1 = (double) 0;
				storer.delete(0, storer.length());
				saver.delete(0, saver.length());
				edt.setText(storer);
				edtans.setText(storer);
			}
		});

		answer.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				storer.delete(0, storer.length());

				storer.append(ans);
				edt.setText(storer);
			}
		});

		equal.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				String a1 = new String(storer);
				String a2 = new String(saver);
				storer.delete(0, storer.length());
				saver.delete(0, saver.length());
				int c1 = 0, c2 = 0;
				for (int i = 0; i < a1.length(); i++) {
					if (a1.charAt(i) == '.') {
						c1++;
					}
				}
				for (int i = 0; i < a2.length(); i++) {
					if (a2.charAt(i) == '.') {
						c2++;
					}
				}
				if (c1 > 1 || c2 > 1) {
					edtans.setText("error");

				} else {
					if (a1.equals("")) {
						a1 = "0";
					}
					if (a2.equals("")) {
						a2 = "0";
					}

					Double value1 = Double.valueOf(a1);
					Double value2 = Double.valueOf(a2);

					if (a1.equals("0") && a2.equals("0") && choice != 0
							&& choice != 8) {
						edtans.setText("Error");
					} else if (choice == 0) {
						storer.delete(0, storer.length());
						storer.append(a1);
					}

					else if (choice == 1) {

						double sum = value1 + value2;
						Double s = sum;
						ans = sum;
						String result = s.toString();
						storer.append(result);
						edtans.setText(result);
						sum = 0;
					} else if (choice == 2) {
						double diff = value2 - value1;
						Double s = diff;
						ans = diff;
						String result = s.toString();
						storer.append(result);
						edtans.setText(result);
						diff = 0;
					} else if (choice == 3) {
						double multi = value1 * value2;
						Double s = multi;
						ans = multi;
						String result = s.toString();
						storer.append(result);
						edtans.setText(result);
						multi = 0;
					} else if (choice == 4) {
						double div;
						if (value1 != 0) {
							div = value2 / value1;
							Double s = div;
							ans = div;
							String result = s.toString();
							storer.append(result);
							edtans.setText(result);
						} else
							edtans.setText("Syntax-Error");

						div = 0;
					} else if (choice == 5) {
						Double pow = Math.pow(value2, value1);
						edtans.setText(pow.toString());
						ans = pow;
					} else if (choice == 6) {
						Double lne = Math.log(value1);
						edtans.setText(lne.toString());
						ans = lne;
					} else if (choice == 7) {
						Double logg = Math.log10(value1);
						edtans.setText(logg.toString());
						ans = logg;
					} else if (choice == 8) {
						Double expo = Math.exp(value1);
						edtans.setText(expo.toString());
						ans = expo;
					} else if (choice == 9) {
						Double sino = Math.sin(value1);
						edtans.setText(sino.toString());
						ans = sino;
					} else if (choice == 10) {
						Double coso = Math.cos(value1);
						edtans.setText(coso.toString());
						ans = coso;
					} else if (choice == 11) {
						Double tano = Math.tan(value1);
						edtans.setText(tano.toString());
						ans = tano;
					} else if (choice == 12) {
						Double sinho = Math.sinh(value1);
						edtans.setText(sinho.toString());
						ans = sinho;
					} else if (choice == 13) {
						Double cosho = Math.cosh(value1);
						edtans.setText(cosho.toString());
						ans = cosho;
					} else if (choice == 14) {
						Double tod = Math.toDegrees(value1);
						edtans.setText(tod.toString());
						ans = tod;
					} else if (choice == 15) {
						Double tor = Math.toRadians(value1);
						edtans.setText(tor.toString());
						ans = tor;
					}
					choice = 0;

					// else {
					// edt.setText("0");
					// }

				}
			}
		});
		divide.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				if (saver.length() > 0) {
					if (choice == 1)
						v1 += Double.valueOf(new String(saver))
								+ Double.valueOf(new String(storer));
					else if (choice == 2)
						v1 += Double.valueOf(new String(saver))
								- Double.valueOf(new String(storer));
					else if (choice == 3)
						v1 += Double.valueOf(new String(saver))
								* Double.valueOf(new String(storer));
					else if (choice == 4)
						v1 += Double.valueOf(new String(saver))
								/ Double.valueOf(new String(storer));
					saver.delete(0, saver.length());
					saver.append(v1.toString());
				} else
					saver.append(storer);
				choice = 4;// divide
				storer.delete(0, storer.length());
				edt.setText(storer);
			}
		});
		multiply.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				if (saver.length() > 0) {
					if (choice == 1)
						v1 += Double.valueOf(new String(saver))
								+ Double.valueOf(new String(storer));
					else if (choice == 2)
						v1 += Double.valueOf(new String(saver))
								- Double.valueOf(new String(storer));
					else if (choice == 3)
						v1 += Double.valueOf(new String(saver))
								* Double.valueOf(new String(storer));
					else if (choice == 4)
						v1 += Double.valueOf(new String(saver))
								/ Double.valueOf(new String(storer));
					saver.delete(0, saver.length());
					saver.append(v1.toString());
				} else
					saver.append(storer);
				choice = 3;// multiply
				storer.delete(0, storer.length());
				edt.setText(storer);
			}
		});
		substract.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				// subtract
				if (saver.length() > 0) {
					if (choice == 1)
						v1 += Double.valueOf(new String(saver))
								+ Double.valueOf(new String(storer));
					else if (choice == 2)
						v1 += Double.valueOf(new String(saver))
								- Double.valueOf(new String(storer));
					else if (choice == 3)
						v1 += Double.valueOf(new String(saver))
								* Double.valueOf(new String(storer));
					else if (choice == 4)
						v1 += Double.valueOf(new String(saver))
								/ Double.valueOf(new String(storer));
					saver.delete(0, saver.length());
					saver.append(v1.toString());
				} else
					saver.append(storer);
				choice = 2;
				storer.delete(0, storer.length());
				edt.setText(storer);
			}
		});

		plus.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				if (saver.length() > 0) {
					if (choice == 1)
						v1 += Double.valueOf(new String(saver))
								+ Double.valueOf(new String(storer));
					else if (choice == 2)
						v1 += Double.valueOf(new String(saver))
								- Double.valueOf(new String(storer));
					else if (choice == 3)
						v1 += Double.valueOf(new String(saver))
								* Double.valueOf(new String(storer));
					else if (choice == 4)
						v1 += Double.valueOf(new String(saver))
								/ Double.valueOf(new String(storer));
					saver.delete(0, saver.length());
					saver.append(v1.toString());
				} else
					saver.append(storer);
				choice = 1;
				storer.delete(0, storer.length());
				edt.setText(storer);

			}
		});
		clear.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (storer.length() > 0) {
					storer.delete(0, storer.length());
					edt.setText(storer);
				}

			}
		});
		zero.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				storer.append(0);
				edt.setText(storer);
			}
		});
		one.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				storer.append(1);
				edt.setText(storer);
			}
		});
		two.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				storer.append(2);
				edt.setText(storer);
			}
		});
		three.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				storer.append(3);
				edt.setText(storer);
			}
		});
		four.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				storer.append(4);
				edt.setText(storer);
			}
		});
		five.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				storer.append(5);
				edt.setText(storer);
			}
		});
		six.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				storer.append(6);
				edt.setText(storer);
			}
		});
		seven.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				storer.append(7);
				edt.setText(storer);
			}
		});
		eight.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				storer.append(8);
				edt.setText(storer);
			}
		});
		nine.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				storer.append(9);
				edt.setText(storer);
			}
		});
		backspace.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (storer.length() > 0) {
					storer.deleteCharAt(storer.length() - 1);
					edt.setText(storer);
				}
			}
		});

	}
}
